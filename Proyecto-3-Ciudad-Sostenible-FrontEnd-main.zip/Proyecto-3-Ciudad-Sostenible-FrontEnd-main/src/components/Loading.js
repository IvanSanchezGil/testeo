export const Loading = () => {
  return <p className="loading">Loading...</p>;
};
