export const Footer = () =>{
    return (<footer>
        (c) 2023 
    </footer>
    )
}