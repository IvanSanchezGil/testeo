const newPost = require('./newPost');
const selectAllPost = require('./selectAllPost');
const selectPostById = require('./selectPostById');
const solvePost = require('./solvePost');



module.exports = {
    newPost,
    selectAllPost,
    selectPostById,
    solvePost
};